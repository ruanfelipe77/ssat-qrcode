<?php

// define('BASE_PATH', dirname(__DIR__) . '/');
// define('BASE_URL', '/qrcode_ssat/'); 

$config = [
    'host' => 'localhost',
    'dbname' => 'qrcode_ssat',
    'username' => 'root',
    'password' => ''
];
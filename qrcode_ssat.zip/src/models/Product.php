<?php

class Product
{
    private $conn;

    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function getAll()
    {
        $stmt = $this->conn->query('SELECT * FROM products');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function create($data)
    {
        $stmt = $this->conn->prepare('INSERT INTO products (serial_number, sale_date, destination, warranty) VALUES (:serial_number, :sale_date, :destination, :warranty)');
        return $stmt->execute([
            'serial_number' => $data['serial_number'],
            'sale_date' => $data['sale_date'],
            'destination' => $data['destination'],
            'warranty' => $data['warranty']
        ]);
    }

    public function update($data)
    {
        $stmt = $this->conn->prepare('UPDATE products SET serial_number = :serial_number, sale_date = :sale_date, destination = :destination, warranty = :warranty WHERE id = :id');
        return $stmt->execute([
            'id' => $data['id'],
            'serial_number' => $data['serial_number'],
            'sale_date' => $data['sale_date'],
            'destination' => $data['destination'],
            'warranty' => $data['warranty']
        ]);
    }

    public function delete($id)
    {
        $stmt = $this->conn->prepare('DELETE FROM products WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    public function getLastInsertId()
    {
        return $this->conn->lastInsertId();
    }

    public function getById($id)
    {
        $stmt = $this->conn->prepare('SELECT * FROM products WHERE id = :id');
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

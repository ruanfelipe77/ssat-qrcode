<nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="public/images/logo_ssat.png" alt="SSAT Logo" style="height: 40px;">
        </a>
    </div>
</nav>

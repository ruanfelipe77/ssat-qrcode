<div class="bg-dark border-right" id="sidebar-wrapper">
    <div class="sidebar-heading text-white">SSAT</div>
    <div class="list-group list-group-flush">
        <a href="#" class="list-group-item list-group-item-action bg-dark text-white">MCPs</a>
    </div>
    <div class="sidebar-footer p-4">
        <form method="POST" action="src/controllers/LogoutController.php">
            <button type="submit" class="btn btn-primary btn-sm btn-block">Sair</button>
        </form>
    </div>
</div>
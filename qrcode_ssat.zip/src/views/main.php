<?php
require 'database.php';
require 'src/models/Product.php';

$database = Database::getInstance();
$db = $database->getConnection();

$productModel = new Product($db);
$products = $productModel->getAll();
?>

<div class="container-fluid">
  <h1 class="mt-4">Lista de MCPs</h1>
  <button class="btn btn-primary mb-3" id="add-mcp">Novo MCP</button>
  <table id="mcp-table" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th>ID</th>
        <th>Número de série</th>
        <th>Data de venda</th>
        <th>Destino</th>
        <th>Garantia</th>
        <th style="width: 180px;">Ações</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($products as $product) : ?>
        <tr>
          <td><?= $product['id'] ?></td>
          <td><?= $product['serial_number'] ?></td>
          <td><?= $product['sale_date'] ?></td>
          <td><?= $product['destination'] ?></td>
          <td><?= $product['warranty'] ?></td>
          <td>
            <button class="btn btn-primary btn-sm edit-mcp" data-id="<?= $product['id'] ?>">Editar</button>
            <button class="btn btn-danger btn-sm delete-mcp" data-id="<?= $product['id'] ?>">Excluir</button>
            <button class="btn btn-info btn-sm print-qrcode" data-id="<?= $product['id']; ?>">QR-Code</button>
          </td>
        </tr>
      <?php endforeach; ?>

    </tbody>
  </table>
</div>
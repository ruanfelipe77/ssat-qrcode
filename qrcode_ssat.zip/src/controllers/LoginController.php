<?php
session_start();
require_once '../../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = $_POST['email'];
  $password = $_POST['password'];
  if ($email === 'admin@centralssat.com.br' && $password === '1234') {
    $_SESSION['logado'] = true;
    // header('Location: ' . BASE_URL . 'index.php');
    // header('Location: ' . BASE_PATH . 'index.php');
    header('Location: ../../index.php');
    exit;
  } else {
    // header('Location: ' . BASE_URL . 'login.php?error=invalid_credentials');
    header('Location: ../../login.php?error=invalid_credentials');
    exit;
  }
}
